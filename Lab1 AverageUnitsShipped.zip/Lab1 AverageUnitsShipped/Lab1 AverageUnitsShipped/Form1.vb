﻿Public Class FrmAverageUnitsShipped

    Dim Sum As Integer = 0
    Dim Number As Integer = 0
    Dim Average As Double = 0

    Private Sub FrmAverageUnitsShipped_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        If IsNumeric(txtUnitsShipped.Text) Then
            Sum = Sum + CInt(txtUnitsShipped.Text)
            Number = Number + 1
            lblDays.Text = "Day " & Number.ToString
            txtRecords.Text = txtRecords.Text & txtUnitsShipped.Text & vbCrLf
        End If

        If (Number = 7) Then
            btnEnter.Enabled = False
            Average = Sum / 7.0
            lblDays.Text = "Day 7"
            txtAverage.Text = "Average/Day: " & Average
        End If

        txtUnitsShipped.Text = ""

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        Sum = 0
        Number = 1
        Average = 0
        txtUnitsShipped.Clear()
        txtRecords.Clear()
        lblDays.Text = "Day " & Number.ToString
        txtAverage.Text = " "
        btnEnter.Enabled = True

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Close()

    End Sub

    Private Sub lblUnits_Click(sender As Object, e As EventArgs) Handles lblUnits.Click

    End Sub

    Private Sub lblDays_Click(sender As Object, e As EventArgs) Handles lblDays.Click

    End Sub

    Private Sub txtUnitsShipped_TextChanged(sender As Object, e As EventArgs) Handles txtUnitsShipped.TextChanged

    End Sub

    Private Sub txtRecords_TextChanged(sender As Object, e As EventArgs) Handles txtRecords.TextChanged

    End Sub

    Private Sub txtAverage_TextChanged(sender As Object, e As EventArgs) Handles txtAverage.TextChanged

    End Sub
End Class
