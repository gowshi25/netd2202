﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSemesterGrades
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCourse1 = New System.Windows.Forms.Label()
        Me.lblCourse2 = New System.Windows.Forms.Label()
        Me.lblCourse3 = New System.Windows.Forms.Label()
        Me.lblCourse4 = New System.Windows.Forms.Label()
        Me.lblCourse5 = New System.Windows.Forms.Label()
        Me.lblCourse6 = New System.Windows.Forms.Label()
        Me.txtCourse1 = New System.Windows.Forms.TextBox()
        Me.txtCourse2 = New System.Windows.Forms.TextBox()
        Me.txtCourse3 = New System.Windows.Forms.TextBox()
        Me.txtCourse4 = New System.Windows.Forms.TextBox()
        Me.txtCourse5 = New System.Windows.Forms.TextBox()
        Me.txtCourse6 = New System.Windows.Forms.TextBox()
        Me.lblSemester = New System.Windows.Forms.Label()
        Me.txtAverage = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblError = New System.Windows.Forms.TextBox()
        Me.lblGrade1 = New System.Windows.Forms.TextBox()
        Me.lblGrade2 = New System.Windows.Forms.TextBox()
        Me.lblGrade3 = New System.Windows.Forms.TextBox()
        Me.lblGrade4 = New System.Windows.Forms.TextBox()
        Me.lblGrade5 = New System.Windows.Forms.TextBox()
        Me.lblGrade6 = New System.Windows.Forms.TextBox()
        Me.lblGrade7 = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblCourse1
        '
        Me.lblCourse1.AutoSize = True
        Me.lblCourse1.Location = New System.Drawing.Point(21, 24)
        Me.lblCourse1.Name = "lblCourse1"
        Me.lblCourse1.Size = New System.Drawing.Size(65, 17)
        Me.lblCourse1.TabIndex = 0
        Me.lblCourse1.Text = "Course 1"
        '
        'lblCourse2
        '
        Me.lblCourse2.AutoSize = True
        Me.lblCourse2.Location = New System.Drawing.Point(21, 52)
        Me.lblCourse2.Name = "lblCourse2"
        Me.lblCourse2.Size = New System.Drawing.Size(65, 17)
        Me.lblCourse2.TabIndex = 1
        Me.lblCourse2.Text = "Course 2"
        '
        'lblCourse3
        '
        Me.lblCourse3.AutoSize = True
        Me.lblCourse3.Location = New System.Drawing.Point(21, 85)
        Me.lblCourse3.Name = "lblCourse3"
        Me.lblCourse3.Size = New System.Drawing.Size(65, 17)
        Me.lblCourse3.TabIndex = 2
        Me.lblCourse3.Text = "Course 3"
        '
        'lblCourse4
        '
        Me.lblCourse4.AutoSize = True
        Me.lblCourse4.Location = New System.Drawing.Point(21, 113)
        Me.lblCourse4.Name = "lblCourse4"
        Me.lblCourse4.Size = New System.Drawing.Size(65, 17)
        Me.lblCourse4.TabIndex = 3
        Me.lblCourse4.Text = "Course 4"
        '
        'lblCourse5
        '
        Me.lblCourse5.AutoSize = True
        Me.lblCourse5.Location = New System.Drawing.Point(21, 141)
        Me.lblCourse5.Name = "lblCourse5"
        Me.lblCourse5.Size = New System.Drawing.Size(65, 17)
        Me.lblCourse5.TabIndex = 4
        Me.lblCourse5.Text = "Course 5"
        '
        'lblCourse6
        '
        Me.lblCourse6.AutoSize = True
        Me.lblCourse6.Location = New System.Drawing.Point(21, 169)
        Me.lblCourse6.Name = "lblCourse6"
        Me.lblCourse6.Size = New System.Drawing.Size(65, 17)
        Me.lblCourse6.TabIndex = 5
        Me.lblCourse6.Text = "Course 6"
        '
        'txtCourse1
        '
        Me.txtCourse1.Location = New System.Drawing.Point(96, 21)
        Me.txtCourse1.Name = "txtCourse1"
        Me.txtCourse1.Size = New System.Drawing.Size(100, 22)
        Me.txtCourse1.TabIndex = 6
        '
        'txtCourse2
        '
        Me.txtCourse2.Location = New System.Drawing.Point(96, 52)
        Me.txtCourse2.Name = "txtCourse2"
        Me.txtCourse2.Size = New System.Drawing.Size(100, 22)
        Me.txtCourse2.TabIndex = 7
        '
        'txtCourse3
        '
        Me.txtCourse3.Location = New System.Drawing.Point(96, 82)
        Me.txtCourse3.Name = "txtCourse3"
        Me.txtCourse3.Size = New System.Drawing.Size(100, 22)
        Me.txtCourse3.TabIndex = 8
        '
        'txtCourse4
        '
        Me.txtCourse4.Location = New System.Drawing.Point(96, 110)
        Me.txtCourse4.Name = "txtCourse4"
        Me.txtCourse4.Size = New System.Drawing.Size(100, 22)
        Me.txtCourse4.TabIndex = 9
        '
        'txtCourse5
        '
        Me.txtCourse5.Location = New System.Drawing.Point(96, 138)
        Me.txtCourse5.Name = "txtCourse5"
        Me.txtCourse5.Size = New System.Drawing.Size(100, 22)
        Me.txtCourse5.TabIndex = 10
        '
        'txtCourse6
        '
        Me.txtCourse6.Location = New System.Drawing.Point(96, 166)
        Me.txtCourse6.Name = "txtCourse6"
        Me.txtCourse6.Size = New System.Drawing.Size(100, 22)
        Me.txtCourse6.TabIndex = 11
        '
        'lblSemester
        '
        Me.lblSemester.AutoSize = True
        Me.lblSemester.Location = New System.Drawing.Point(21, 198)
        Me.lblSemester.Name = "lblSemester"
        Me.lblSemester.Size = New System.Drawing.Size(68, 17)
        Me.lblSemester.TabIndex = 18
        Me.lblSemester.Text = "Semester"
        '
        'txtAverage
        '
        Me.txtAverage.Location = New System.Drawing.Point(96, 195)
        Me.txtAverage.Name = "txtAverage"
        Me.txtAverage.ReadOnly = True
        Me.txtAverage.Size = New System.Drawing.Size(100, 22)
        Me.txtAverage.TabIndex = 19
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(12, 469)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(84, 38)
        Me.btnCalculate.TabIndex = 22
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(114, 468)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(82, 39)
        Me.btnReset.TabIndex = 23
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(215, 468)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(82, 39)
        Me.btnExit.TabIndex = 24
        Me.btnExit.Text = "&Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblError
        '
        Me.lblError.Location = New System.Drawing.Point(24, 225)
        Me.lblError.Multiline = True
        Me.lblError.Name = "lblError"
        Me.lblError.Size = New System.Drawing.Size(261, 238)
        Me.lblError.TabIndex = 25
        '
        'lblGrade1
        '
        Me.lblGrade1.Location = New System.Drawing.Point(215, 21)
        Me.lblGrade1.Name = "lblGrade1"
        Me.lblGrade1.ReadOnly = True
        Me.lblGrade1.Size = New System.Drawing.Size(70, 22)
        Me.lblGrade1.TabIndex = 26
        '
        'lblGrade2
        '
        Me.lblGrade2.Location = New System.Drawing.Point(215, 49)
        Me.lblGrade2.Name = "lblGrade2"
        Me.lblGrade2.ReadOnly = True
        Me.lblGrade2.Size = New System.Drawing.Size(70, 22)
        Me.lblGrade2.TabIndex = 27
        '
        'lblGrade3
        '
        Me.lblGrade3.Location = New System.Drawing.Point(215, 82)
        Me.lblGrade3.Name = "lblGrade3"
        Me.lblGrade3.ReadOnly = True
        Me.lblGrade3.Size = New System.Drawing.Size(70, 22)
        Me.lblGrade3.TabIndex = 28
        '
        'lblGrade4
        '
        Me.lblGrade4.Location = New System.Drawing.Point(215, 110)
        Me.lblGrade4.Name = "lblGrade4"
        Me.lblGrade4.ReadOnly = True
        Me.lblGrade4.Size = New System.Drawing.Size(70, 22)
        Me.lblGrade4.TabIndex = 29
        '
        'lblGrade5
        '
        Me.lblGrade5.Location = New System.Drawing.Point(215, 138)
        Me.lblGrade5.Name = "lblGrade5"
        Me.lblGrade5.ReadOnly = True
        Me.lblGrade5.Size = New System.Drawing.Size(70, 22)
        Me.lblGrade5.TabIndex = 30
        '
        'lblGrade6
        '
        Me.lblGrade6.Location = New System.Drawing.Point(215, 166)
        Me.lblGrade6.Name = "lblGrade6"
        Me.lblGrade6.ReadOnly = True
        Me.lblGrade6.Size = New System.Drawing.Size(70, 22)
        Me.lblGrade6.TabIndex = 31
        '
        'lblGrade7
        '
        Me.lblGrade7.Location = New System.Drawing.Point(215, 195)
        Me.lblGrade7.Name = "lblGrade7"
        Me.lblGrade7.ReadOnly = True
        Me.lblGrade7.Size = New System.Drawing.Size(70, 22)
        Me.lblGrade7.TabIndex = 32
        '
        'frmSemesterGrades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(326, 519)
        Me.Controls.Add(Me.lblGrade7)
        Me.Controls.Add(Me.lblGrade6)
        Me.Controls.Add(Me.lblGrade5)
        Me.Controls.Add(Me.lblGrade4)
        Me.Controls.Add(Me.lblGrade3)
        Me.Controls.Add(Me.lblGrade2)
        Me.Controls.Add(Me.lblGrade1)
        Me.Controls.Add(Me.lblError)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtAverage)
        Me.Controls.Add(Me.lblSemester)
        Me.Controls.Add(Me.txtCourse6)
        Me.Controls.Add(Me.txtCourse5)
        Me.Controls.Add(Me.txtCourse4)
        Me.Controls.Add(Me.txtCourse3)
        Me.Controls.Add(Me.txtCourse2)
        Me.Controls.Add(Me.txtCourse1)
        Me.Controls.Add(Me.lblCourse6)
        Me.Controls.Add(Me.lblCourse5)
        Me.Controls.Add(Me.lblCourse4)
        Me.Controls.Add(Me.lblCourse3)
        Me.Controls.Add(Me.lblCourse2)
        Me.Controls.Add(Me.lblCourse1)
        Me.Name = "frmSemesterGrades"
        Me.Text = "Semester Grades"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCourse1 As Label
    Friend WithEvents lblCourse2 As Label
    Friend WithEvents lblCourse3 As Label
    Friend WithEvents lblCourse4 As Label
    Friend WithEvents lblCourse5 As Label
    Friend WithEvents lblCourse6 As Label
    Friend WithEvents txtCourse1 As TextBox
    Friend WithEvents txtCourse2 As TextBox
    Friend WithEvents txtCourse3 As TextBox
    Friend WithEvents txtCourse4 As TextBox
    Friend WithEvents txtCourse5 As TextBox
    Friend WithEvents txtCourse6 As TextBox
    Friend WithEvents lblSemester As Label
    Friend WithEvents txtAverage As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblError As TextBox
    Friend WithEvents lblGrade1 As TextBox
    Friend WithEvents lblGrade2 As TextBox
    Friend WithEvents lblGrade3 As TextBox
    Friend WithEvents lblGrade4 As TextBox
    Friend WithEvents lblGrade5 As TextBox
    Friend WithEvents lblGrade6 As TextBox
    Friend WithEvents lblGrade7 As TextBox
End Class
