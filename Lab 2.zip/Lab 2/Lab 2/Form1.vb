﻿' Author: Cowshigan Varnakunasingam
' Date:   February 8th, 2019
' Description: Semester Calculator, Averaging 6 Courses

Public Class frmSemesterGrades

    'DECLARATION

    Const MIN_Grade As Double = 0.0
    Const MAX_Grade As Double = 100.0
    Const DISPLAY_Error As String = "Error(s)"
    Dim AverageGrade As Double
    Dim CalculateCall As Boolean = False

    Private Sub frmSemesterGrades_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Sub ResetForm()

        txtCourse1.Text = ""
        txtCourse2.Text = ""
        txtCourse3.Text = ""
        txtCourse4.Text = ""
        txtCourse5.Text = ""
        txtCourse6.Text = ""
        lblGrade1.Text = "               "
        lblGrade2.Text = "               "
        lblGrade3.Text = "               "
        lblGrade4.Text = "               "
        lblGrade5.Text = "               "
        lblGrade6.Text = "               "
        lblGrade7.Text = "               "
        txtAverage.Text = ""
        lblError.Text = ""

        btnCalculate.Enabled = True
        txtCourse1.ReadOnly = False
        txtCourse2.ReadOnly = False
        txtCourse3.ReadOnly = False
        txtCourse4.ReadOnly = False
        txtCourse5.ReadOnly = False
        txtCourse6.ReadOnly = False

        txtCourse1.Focus()
        CalculateCall = False
        AverageGrade = 0

    End Sub

    Sub Button_Click()

        CalculateCall = False

    End Sub

    Sub Course1()

        Dim UserInput As String = txtCourse1.Text

        If (ValidateInput(UserInput)) Then
            lblError.Text = ""
            If (CInt(UserInput) >= 90 AndAlso CInt(UserInput) <= 100) Then
                lblGrade1.Text = "A+"
            ElseIf (CInt(UserInput) >= 85 AndAlso CInt(UserInput) <= 89) Then
                lblGrade1.Text = "A"
            ElseIf (CInt(UserInput) >= 80 AndAlso CInt(UserInput) <= 84) Then
                lblGrade1.Text = "A-"
            ElseIf (CInt(UserInput) >= 77 AndAlso CInt(UserInput) <= 79) Then
                lblGrade1.Text = "B+"
            ElseIf (CInt(UserInput) >= 73 AndAlso CInt(UserInput) <= 76) Then
                lblGrade1.Text = "B"
            ElseIf (CInt(UserInput) >= 70 AndAlso CInt(UserInput) <= 72) Then
                lblGrade1.Text = "B-"
            ElseIf (CInt(UserInput) >= 67 AndAlso CInt(UserInput) <= 69) Then
                lblGrade1.Text = "C+"
            ElseIf (CInt(UserInput) >= 63 AndAlso CInt(UserInput) <= 66) Then
                lblGrade1.Text = "C"
            ElseIf (CInt(UserInput) >= 60 AndAlso CInt(UserInput) <= 62) Then
                lblGrade1.Text = "C-"
            ElseIf (CInt(UserInput) >= 57 AndAlso CInt(UserInput) <= 59) Then
                lblGrade1.Text = "D+"
            ElseIf (CInt(UserInput) >= 53 AndAlso CInt(UserInput) <= 56) Then
                lblGrade1.Text = "D"
            ElseIf (CInt(UserInput) >= 50 AndAlso CInt(UserInput) <= 52) Then
                lblGrade1.Text = "D-"
            Else
                lblGrade1.Text = "F"
            End If
        Else
            If (txtCourse1.Text = "") Then
                lblError.Text = ""
                lblGrade1.Text = ""
            Else
                btnCalculate.Enabled = False
                lblGrade1.Text = ""
                lblError.Text = "Range of value must be within 0 and 100, Please try again!" + vbCrLf
            End If
        End If

    End Sub

    Sub Course2()

        Dim UserInput As String = txtCourse2.Text

        If (ValidateInput(UserInput)) Then
            lblError.Text = ""
            If (CInt(UserInput) >= 90 AndAlso CInt(UserInput) <= 100) Then
                lblGrade2.Text = "A+"
            ElseIf (CInt(UserInput) >= 85 AndAlso CInt(UserInput) <= 89) Then
                lblGrade2.Text = "A"
            ElseIf (CInt(UserInput) >= 80 AndAlso CInt(UserInput) <= 84) Then
                lblGrade2.Text = "A-"
            ElseIf (CInt(UserInput) >= 77 AndAlso CInt(UserInput) <= 79) Then
                lblGrade2.Text = "B+"
            ElseIf (CInt(UserInput) >= 73 AndAlso CInt(UserInput) <= 76) Then
                lblGrade2.Text = "B"
            ElseIf (CInt(UserInput) >= 70 AndAlso CInt(UserInput) <= 72) Then
                lblGrade2.Text = "B-"
            ElseIf (CInt(UserInput) >= 67 AndAlso CInt(UserInput) <= 69) Then
                lblGrade2.Text = "C+"
            ElseIf (CInt(UserInput) >= 63 AndAlso CInt(UserInput) <= 66) Then
                lblGrade2.Text = "C"
            ElseIf (CInt(UserInput) >= 60 AndAlso CInt(UserInput) <= 62) Then
                lblGrade2.Text = "C-"
            ElseIf (CInt(UserInput) >= 57 AndAlso CInt(UserInput) <= 59) Then
                lblGrade2.Text = "D+"
            ElseIf (CInt(UserInput) >= 53 AndAlso CInt(UserInput) <= 56) Then
                lblGrade2.Text = "D"
            ElseIf (CInt(UserInput) >= 50 AndAlso CInt(UserInput) <= 52) Then
                lblGrade2.Text = "D-"
            Else
                lblGrade2.Text = "F"
            End If
        Else
            If (txtCourse2.Text = "") Then
                lblError.Text = ""
                lblGrade2.Text = ""
            Else
                btnCalculate.Enabled = False
                lblGrade2.Text = ""
                lblError.Text = "Range of value must be within 0 and 100, Please try again!" + vbCrLf
            End If
        End If

    End Sub

    Sub Course3()

        Dim UserInput As String = txtCourse3.Text

        If (ValidateInput(UserInput)) Then
            lblError.Text = ""
            If (CInt(UserInput) >= 90 AndAlso CInt(UserInput) <= 100) Then
                lblGrade3.Text = "A+"
            ElseIf (CInt(UserInput) >= 85 AndAlso CInt(UserInput) <= 89) Then
                lblGrade1.Text = "A"
            ElseIf (CInt(UserInput) >= 80 AndAlso CInt(UserInput) <= 84) Then
                lblGrade3.Text = "A-"
            ElseIf (CInt(UserInput) >= 77 AndAlso CInt(UserInput) <= 79) Then
                lblGrade3.Text = "B+"
            ElseIf (CInt(UserInput) >= 73 AndAlso CInt(UserInput) <= 76) Then
                lblGrade3.Text = "B"
            ElseIf (CInt(UserInput) >= 70 AndAlso CInt(UserInput) <= 72) Then
                lblGrade3.Text = "B-"
            ElseIf (CInt(UserInput) >= 67 AndAlso CInt(UserInput) <= 69) Then
                lblGrade3.Text = "C+"
            ElseIf (CInt(UserInput) >= 63 AndAlso CInt(UserInput) <= 66) Then
                lblGrade3.Text = "C"
            ElseIf (CInt(UserInput) >= 60 AndAlso CInt(UserInput) <= 62) Then
                lblGrade3.Text = "C-"
            ElseIf (CInt(UserInput) >= 57 AndAlso CInt(UserInput) <= 59) Then
                lblGrade3.Text = "D+"
            ElseIf (CInt(UserInput) >= 53 AndAlso CInt(UserInput) <= 56) Then
                lblGrade3.Text = "D"
            ElseIf (CInt(UserInput) >= 50 AndAlso CInt(UserInput) <= 52) Then
                lblGrade3.Text = "D-"
            Else
                lblGrade3.Text = "F"
            End If
        Else
            If (txtCourse3.Text = "") Then
                lblError.Text = ""
                lblGrade3.Text = ""
            Else
                btnCalculate.Enabled = False
                lblGrade3.Text = ""
                lblError.Text = "Range of value must be within 0 and 100, Please try again!" + vbCrLf
            End If
        End If

    End Sub

    Sub Course4()

        Dim UserInput As String = txtCourse4.Text

        If (ValidateInput(UserInput)) Then
            lblError.Text = ""
            If (CInt(UserInput) >= 90 AndAlso CInt(UserInput) <= 100) Then
                lblGrade4.Text = "A+"
            ElseIf (CInt(UserInput) >= 85 AndAlso CInt(UserInput) <= 89) Then
                lblGrade4.Text = "A"
            ElseIf (CInt(UserInput) >= 80 AndAlso CInt(UserInput) <= 84) Then
                lblGrade4.Text = "A-"
            ElseIf (CInt(UserInput) >= 77 AndAlso CInt(UserInput) <= 79) Then
                lblGrade4.Text = "B+"
            ElseIf (CInt(UserInput) >= 73 AndAlso CInt(UserInput) <= 76) Then
                lblGrade4.Text = "B"
            ElseIf (CInt(UserInput) >= 70 AndAlso CInt(UserInput) <= 72) Then
                lblGrade4.Text = "B-"
            ElseIf (CInt(UserInput) >= 67 AndAlso CInt(UserInput) <= 69) Then
                lblGrade4.Text = "C+"
            ElseIf (CInt(UserInput) >= 63 AndAlso CInt(UserInput) <= 66) Then
                lblGrade4.Text = "C"
            ElseIf (CInt(UserInput) >= 60 AndAlso CInt(UserInput) <= 62) Then
                lblGrade4.Text = "C-"
            ElseIf (CInt(UserInput) >= 57 AndAlso CInt(UserInput) <= 59) Then
                lblGrade4.Text = "D+"
            ElseIf (CInt(UserInput) >= 53 AndAlso CInt(UserInput) <= 56) Then
                lblGrade4.Text = "D"
            ElseIf (CInt(UserInput) >= 50 AndAlso CInt(UserInput) <= 52) Then
                lblGrade4.Text = "D-"
            Else
                lblGrade4.Text = "F"
            End If
        Else
            If (txtCourse4.Text = "") Then
                lblError.Text = ""
                lblGrade4.Text = ""
            Else
                btnCalculate.Enabled = False
                lblGrade4.Text = ""
                lblError.Text = "Range of value must be within 0 and 100, Please try again!" + vbCrLf
            End If
        End If

    End Sub

    Sub Course5()

        Dim UserInput As String = txtCourse5.Text

        If (ValidateInput(UserInput)) Then
            lblError.Text = ""
            If (CInt(UserInput) >= 90 AndAlso CInt(UserInput) <= 100) Then
                lblGrade5.Text = "A+"
            ElseIf (CInt(UserInput) >= 85 AndAlso CInt(UserInput) <= 89) Then
                lblGrade5.Text = "A"
            ElseIf (CInt(UserInput) >= 80 AndAlso CInt(UserInput) <= 84) Then
                lblGrade5.Text = "A-"
            ElseIf (CInt(UserInput) >= 77 AndAlso CInt(UserInput) <= 79) Then
                lblGrade5.Text = "B+"
            ElseIf (CInt(UserInput) >= 73 AndAlso CInt(UserInput) <= 76) Then
                lblGrade5.Text = "B"
            ElseIf (CInt(UserInput) >= 70 AndAlso CInt(UserInput) <= 72) Then
                lblGrade5.Text = "B-"
            ElseIf (CInt(UserInput) >= 67 AndAlso CInt(UserInput) <= 69) Then
                lblGrade5.Text = "C+"
            ElseIf (CInt(UserInput) >= 63 AndAlso CInt(UserInput) <= 66) Then
                lblGrade5.Text = "C"
            ElseIf (CInt(UserInput) >= 60 AndAlso CInt(UserInput) <= 62) Then
                lblGrade5.Text = "C-"
            ElseIf (CInt(UserInput) >= 57 AndAlso CInt(UserInput) <= 59) Then
                lblGrade5.Text = "D+"
            ElseIf (CInt(UserInput) >= 53 AndAlso CInt(UserInput) <= 56) Then
                lblGrade5.Text = "D"
            ElseIf (CInt(UserInput) >= 50 AndAlso CInt(UserInput) <= 52) Then
                lblGrade5.Text = "D-"
            Else
                lblGrade5.Text = "F"
            End If
        Else
            If (txtCourse5.Text = "") Then
                lblError.Text = ""
                lblGrade5.Text = ""
            Else
                btnCalculate.Enabled = False
                lblGrade5.Text = ""
                lblError.Text = "Range of value must be within 0 and 100, Please try again!" + vbCrLf
            End If
        End If

    End Sub

    Sub Course6()

        Dim UserInput As String = txtCourse6.Text

        If (ValidateInput(UserInput)) Then
            lblError.Text = ""
            If (CInt(UserInput) >= 90 AndAlso CInt(UserInput) <= 100) Then
                lblGrade6.Text = "A+"
            ElseIf (CInt(UserInput) >= 85 AndAlso CInt(UserInput) <= 89) Then
                lblGrade6.Text = "A"
            ElseIf (CInt(UserInput) >= 80 AndAlso CInt(UserInput) <= 84) Then
                lblGrade6.Text = "A-"
            ElseIf (CInt(UserInput) >= 77 AndAlso CInt(UserInput) <= 79) Then
                lblGrade6.Text = "B+"
            ElseIf (CInt(UserInput) >= 73 AndAlso CInt(UserInput) <= 76) Then
                lblGrade6.Text = "B"
            ElseIf (CInt(UserInput) >= 70 AndAlso CInt(UserInput) <= 72) Then
                lblGrade6.Text = "B-"
            ElseIf (CInt(UserInput) >= 67 AndAlso CInt(UserInput) <= 69) Then
                lblGrade6.Text = "C+"
            ElseIf (CInt(UserInput) >= 63 AndAlso CInt(UserInput) <= 66) Then
                lblGrade6.Text = "C"
            ElseIf (CInt(UserInput) >= 60 AndAlso CInt(UserInput) <= 62) Then
                lblGrade6.Text = "C-"
            ElseIf (CInt(UserInput) >= 57 AndAlso CInt(UserInput) <= 59) Then
                lblGrade6.Text = "D+"
            ElseIf (CInt(UserInput) >= 53 AndAlso CInt(UserInput) <= 56) Then
                lblGrade6.Text = "D"
            ElseIf (CInt(UserInput) >= 50 AndAlso CInt(UserInput) <= 52) Then
                lblGrade6.Text = "D-"
            Else
                lblGrade6.Text = "F"
            End If
        Else
            If (txtCourse6.Text = "") Then
                lblError.Text = ""
                lblGrade6.Text = ""
            Else
                btnCalculate.Enabled = False
                lblGrade6.Text = ""
                lblError.Text = "Range of value must be within 0 and 100, Please try again!" + vbCrLf
            End If
        End If

    End Sub

    Sub SemesterGrade()

        If (AverageGrade >= 90 AndAlso AverageGrade <= 100) Then
            lblGrade7.Text = "A+"
        ElseIf (AverageGrade >= 85 AndAlso AverageGrade <= 89) Then
            lblGrade7.Text = "A"
        ElseIf (AverageGrade >= 80 AndAlso AverageGrade <= 84) Then
            lblGrade7.Text = "A-"
        ElseIf (AverageGrade >= 77 AndAlso AverageGrade <= 79) Then
            lblGrade7.Text = "B+"
        ElseIf (AverageGrade >= 73 AndAlso AverageGrade <= 76) Then
            lblGrade7.Text = "B"
        ElseIf (AverageGrade >= 70 AndAlso AverageGrade <= 72) Then
            lblGrade7.Text = "B-"
        ElseIf (AverageGrade >= 67 AndAlso AverageGrade <= 69) Then
            lblGrade7.Text = "C+"
        ElseIf (AverageGrade >= 63 AndAlso AverageGrade <= 66) Then
            lblGrade7.Text = "C"
        ElseIf (AverageGrade >= 60 AndAlso AverageGrade <= 62) Then
            lblGrade7.Text = "C-"
        ElseIf (AverageGrade >= 57 AndAlso AverageGrade <= 59) Then
            lblGrade7.Text = "D+"
        ElseIf (AverageGrade >= 53 AndAlso AverageGrade <= 56) Then
            lblGrade7.Text = "D"
        ElseIf (AverageGrade >= 50 AndAlso AverageGrade <= 52) Then
            lblGrade7.Text = "D-"
        Else
            lblGrade7.Text = "F"
        End If
    End Sub

    Function ValidateInput(ByVal input As String) As Boolean

        Dim InputNumber As Double
        Dim isValidInput As Boolean = False

        Try
            InputNumber = CInt(input)
            If (InputNumber >= MIN_Grade AndAlso InputNumber <= MAX_Grade) Then
                isValidInput = True
            End If
        Catch ex As Exception
        End Try

        Return isValidInput

    End Function

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        CalculateCall = True
        btnCalculate.Enabled = False
        txtCourse1.ReadOnly = True
        txtCourse2.ReadOnly = True
        txtCourse3.ReadOnly = True
        txtCourse4.ReadOnly = True
        txtCourse5.ReadOnly = True
        txtCourse6.ReadOnly = True

        If (CalculateCall AndAlso txtCourse1.Text = "") Then
            lblError.Text += "Range of value must be within 0 and 100, Please try again!" + vbCrLf
        Else
            Call Course1()
        End If
        If (CalculateCall AndAlso txtCourse2.Text = "") Then
            lblError.Text += "Range of value must be within 0 and 100, Please try again!" + vbCrLf
        Else
            Call Course2()
        End If
        If (CalculateCall AndAlso txtCourse3.Text = "") Then
            lblError.Text += "Range of value must be within 0 and 100, Please try again!" + vbCrLf
        Else
            Call Course3()
        End If
        If (CalculateCall AndAlso txtCourse4.Text = "") Then
            lblError.Text += "Range of value must be within 0 and 100, Please try again!" + vbCrLf
        Else
            Call Course4()
        End If
        If (CalculateCall AndAlso txtCourse5.Text = "") Then
            lblError.Text += "Range of value must be within 0 and 100, Please try again!" + vbCrLf
        Else
            Call Course5()
        End If
        If (CalculateCall AndAlso txtCourse6.Text = "") Then
            lblError.Text += "Range of value must be within 0 and 100, Please try again!" + vbCrLf
        Else
            Call Course6()
        End If

        If (lblError.Text = "" AndAlso txtAverage.Text = "") Then
            AverageGrade = (CInt(txtCourse1.Text) + CInt(txtCourse2.Text) + CInt(txtCourse3.Text) + CInt(txtCourse4.Text) + CInt(txtCourse5.Text) + CInt(txtCourse6.Text)) / 6
            txtAverage.Text = AverageGrade.ToString
            Call SemesterGrade()
        End If

        btnReset.Focus()

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        Call ResetForm()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Application.Exit()

    End Sub

    Private Sub lblCourse1_Click(sender As Object, e As EventArgs) Handles lblCourse1.Click

    End Sub

    Private Sub lblCourse2_Click(sender As Object, e As EventArgs) Handles lblCourse2.Click

    End Sub

    Private Sub lblCourse3_Click(sender As Object, e As EventArgs) Handles lblCourse3.Click

    End Sub

    Private Sub lblCourse4_Click(sender As Object, e As EventArgs) Handles lblCourse4.Click

    End Sub

    Private Sub lblCourse5_Click(sender As Object, e As EventArgs) Handles lblCourse5.Click

    End Sub

    Private Sub lblCourse6_Click(sender As Object, e As EventArgs) Handles lblCourse6.Click

    End Sub

    Private Sub lblSemester_Click(sender As Object, e As EventArgs) Handles lblSemester.Click

    End Sub

    Private Sub txtCourse1_TextChanged(sender As Object, e As EventArgs) Handles txtCourse1.TextChanged

        Call Course1()
        Call Course2()
        Call Course3()
        Call Course4()
        Call Course5()
        Call Course6()
        If (lblError.Text = "") Then
            btnCalculate.Enabled = True
        Else
            btnCalculate.Enabled = False
        End If

    End Sub

    Private Sub txtCourse2_TextChanged(sender As Object, e As EventArgs) Handles txtCourse2.TextChanged

        Call Course1()
        Call Course2()
        Call Course3()
        Call Course4()
        Call Course5()
        Call Course6()
        If (lblError.Text = "") Then
            btnCalculate.Enabled = True
        Else
            btnCalculate.Enabled = False
        End If

    End Sub

    Private Sub txtCourse3_TextChanged(sender As Object, e As EventArgs) Handles txtCourse3.TextChanged

        Call Course1()
        Call Course2()
        Call Course3()
        Call Course4()
        Call Course5()
        Call Course6()
        If (lblError.Text = "") Then
            btnCalculate.Enabled = True
        Else
            btnCalculate.Enabled = False
        End If

    End Sub

    Private Sub txtCourse4_TextChanged(sender As Object, e As EventArgs) Handles txtCourse4.TextChanged

        Call Course1()
        Call Course2()
        Call Course3()
        Call Course4()
        Call Course5()
        Call Course6()
        If (lblError.Text = "") Then
            btnCalculate.Enabled = True
        Else
            btnCalculate.Enabled = False
        End If

    End Sub

    Private Sub txtCourse5_TextChanged(sender As Object, e As EventArgs) Handles txtCourse5.TextChanged

        Call Course1()
        Call Course2()
        Call Course3()
        Call Course4()
        Call Course5()
        Call Course6()
        If (lblError.Text = "") Then
            btnCalculate.Enabled = True
        Else
            btnCalculate.Enabled = False
        End If

    End Sub

    Private Sub txtCourse6_TextChanged(sender As Object, e As EventArgs) Handles txtCourse6.TextChanged

        Call Course1()
        Call Course2()
        Call Course3()
        Call Course4()
        Call Course5()
        Call Course6()
        If (lblError.Text = "") Then
            btnCalculate.Enabled = True
        Else
            btnCalculate.Enabled = False
        End If

    End Sub

    Private Sub txtAverage_TextChanged(sender As Object, e As EventArgs) Handles txtAverage.TextChanged

    End Sub

    Private Sub lblGrade1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblGrade2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblGrade3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblGrade4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblGrade5_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblGrade6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblGrade7_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblError_Click(sender As Object, e As EventArgs)

    End Sub
End Class
