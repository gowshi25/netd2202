﻿Option Strict On    ' Force compiler to adhere to more strict rules

' Author:         Cowshigan Varnakunasingam
' Student #:      100706882
' Description:    A VB Form that validates inputed values, stores the content and addresses the results of the average units per day per employee over 7 days.

Public Class frmAverageUnitsShippedByEmployee

#Region "Declarations"
    Const MIN_Value As Integer = 0      ' Minimum allowed value
    Const MAX_Value As Integer = 1000   ' Maximum allowed value
    Dim TOTAL_Average As Double = 0
    Dim Units(6) As Integer
    Dim Day As Integer = 1

    Private columnCounter As Integer = 0
    Private rowCounter As Integer = 0
    Private Const numberColumnLastIndex As Integer = 2
    Private Const numberRowLastIndex As Integer = 6
    Private numberArray(numberRowLastIndex, numberColumnLastIndex) As Double
    Private Const indexValueLabels As Integer = 0
    Private Const indexRowColumnLabels As Integer = 1
#End Region

#Region "Subs"
    Sub dataDisplay()
        numberArray(rowCounter, columnCounter) = Convert.ToDouble(txtUnits.Text)

        If (columnCounter = 0) Then
            lblUnits1.Text += numberArray(rowCounter, columnCounter).ToString() & " "

            If rowCounter < numberRowLastIndex Then

                rowCounter += 1

                lblUnits1.Text += vbCrLf

            ElseIf rowCounter = numberRowLastIndex And columnCounter = numberColumnLastIndex Then
                btnEnter.Enabled = False
                txtUnits.Text = ""
                txtUnits.ReadOnly = True
                btnReset().Focus()
            Else

                columnCounter += 1
                rowCounter = 0
                lblAverage1.Text = "Average: " + averageArray(Units).ToString
                TOTAL_Average = TOTAL_Average + averageArray(Units)
            End If

            txtUnits.Text = String.Empty

        ElseIf (columnCounter = 1) Then
            lblUnits2.Text += numberArray(rowCounter, columnCounter).ToString() & " "

            If rowCounter < numberRowLastIndex Then

                rowCounter += 1

                lblUnits2.Text += vbCrLf

            ElseIf rowCounter = numberRowLastIndex And columnCounter = numberColumnLastIndex Then
                btnEnter.Enabled = False
                txtUnits.Text = ""
                txtUnits.ReadOnly = True
                btnReset().Focus()
            Else
                columnCounter += 1
                rowCounter = 0
                lblAverage2.Text = "Average: " + averageArray(Units).ToString
                TOTAL_Average = TOTAL_Average + averageArray(Units)
            End If

            txtUnits.Text = String.Empty

        ElseIf (columnCounter = 2) Then
            lblUnits3.Text += numberArray(rowCounter, columnCounter).ToString() & " "

            If rowCounter < numberRowLastIndex Then

                rowCounter += 1

                lblUnits3.Text += vbCrLf

            ElseIf rowCounter = numberRowLastIndex And columnCounter = numberColumnLastIndex Then
                btnEnter.Enabled = False
                txtUnits.Text = ""
                txtUnits.ReadOnly = True
                btnReset().Focus()
            Else

                columnCounter += 1
                rowCounter = 0
                TOTAL_Average = TOTAL_Average + averageArray(Units)
            End If

            txtUnits.Text = String.Empty
        End If

    End Sub

    Sub resetForm()

        Day = 1
        Array.Clear(Units, 0, Units.Length)

        txtUnits.Text = ""
        lblDays.Text = "Day 1"
        lblUnits1.Text = ""
        lblUnits2.Text = ""
        lblUnits3.Text = ""
        lblAverage1.Text = ""
        lblAverage2.Text = ""
        lblAverage3.Text = ""
        lblTotalAverage.Text = ""
        columnCounter = 0
        rowCounter = 0
        btnEnter.Enabled = True
        txtUnits.ReadOnly = False

        txtUnits.Focus()
    End Sub
#End Region

#Region "Functions"
    Function validateInput(ByVal Input As String) As Boolean
        Dim userInput As Integer
        Dim isValid As Boolean = False

        Try
            userInput = CInt(Input)
            If (Input.Equals(userInput.ToString)) Then
                If (userInput >= MIN_Value AndAlso userInput <= MAX_Value) Then
                    isValid = True
                End If
            End If
        Catch ex As Exception
        End Try

        Return isValid
    End Function

    Function averageArray(ByVal arrayToAverage() As Integer) As Double
        Dim allTotal As Integer

        For Each dailyTotal In arrayToAverage
            allTotal += dailyTotal
        Next

        averageArray = Math.Round(allTotal / arrayToAverage.Length, 2)
    End Function

#End Region

    Private Sub frmAverageUnitsShippedByEmployee_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblDays_Click(sender As Object, e As EventArgs) Handles lblDays.Click

    End Sub

    Private Sub lblUnits_Click(sender As Object, e As EventArgs) Handles lblUnits.Click

    End Sub

    Private Sub txtUnits_TextChanged(sender As Object, e As EventArgs) Handles txtUnits.TextChanged

    End Sub

    Private Sub lblEm1_Click(sender As Object, e As EventArgs) Handles lblEm1.Click

    End Sub

    Private Sub lblEm2_Click(sender As Object, e As EventArgs) Handles lblEm2.Click

    End Sub

    Private Sub lblEm3_Click(sender As Object, e As EventArgs) Handles lblEm3.Click

    End Sub

    Private Sub lblUnits1_Click(sender As Object, e As EventArgs) Handles lblUnits1.Click

    End Sub

    Private Sub lblUnits2_Click(sender As Object, e As EventArgs) Handles lblUnits2.Click

    End Sub

    Private Sub lblUnits3_Click(sender As Object, e As EventArgs) Handles lblUnits3.Click

    End Sub

    Private Sub lblAverage1_Click(sender As Object, e As EventArgs) Handles lblAverage1.Click

    End Sub

    Private Sub lblAverage2_Click(sender As Object, e As EventArgs) Handles lblAverage2.Click

    End Sub

    Private Sub lblAverage3_Click(sender As Object, e As EventArgs) Handles lblAverage3.Click

    End Sub

    Private Sub lblTotalAverage_Click(sender As Object, e As EventArgs) Handles lblTotalAverage.Click

    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        Dim userInput As String = txtUnits.Text

        If (validateInput(userInput)) Then

            Units(Day - 1) = Convert.ToInt32(userInput)

            Call dataDisplay()

            If (Day < 7) Then
                Day = Day + 1
                lblDays.Text = "Day " + Day.ToString
            Else
                If (btnEnter.Enabled = False) Then
                    lblDays.Text = "Done"
                    lblAverage3.Text = "Average: " + averageArray(Units).ToString
                    TOTAL_Average = (TOTAL_Average + averageArray(Units)) / 3
                    lblTotalAverage.Text = "Average p/Day: " + TOTAL_Average.ToString
                Else
                    Day = 1

                End If
            End If

        Else
            MessageBox.Show("Make sure the value of units shipped are between 0 and 1000!", "Invalid Entry", MessageBoxButtons.OK)
        End If

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Call resetForm()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub
End Class
