﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAverageUnitsShippedByEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblAverage1 = New System.Windows.Forms.Label()
        Me.lblAverage2 = New System.Windows.Forms.Label()
        Me.lblAverage3 = New System.Windows.Forms.Label()
        Me.lblTotalAverage = New System.Windows.Forms.Label()
        Me.lblUnits3 = New System.Windows.Forms.Label()
        Me.lblUnits2 = New System.Windows.Forms.Label()
        Me.lblUnits1 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.lblEm3 = New System.Windows.Forms.Label()
        Me.lblEm2 = New System.Windows.Forms.Label()
        Me.lblEm1 = New System.Windows.Forms.Label()
        Me.txtUnits = New System.Windows.Forms.TextBox()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.lblDays = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblAverage1
        '
        Me.lblAverage1.BackColor = System.Drawing.SystemColors.Control
        Me.lblAverage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAverage1.Location = New System.Drawing.Point(10, 289)
        Me.lblAverage1.Name = "lblAverage1"
        Me.lblAverage1.Size = New System.Drawing.Size(132, 23)
        Me.lblAverage1.TabIndex = 36
        '
        'lblAverage2
        '
        Me.lblAverage2.BackColor = System.Drawing.SystemColors.Control
        Me.lblAverage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAverage2.Location = New System.Drawing.Point(162, 289)
        Me.lblAverage2.Name = "lblAverage2"
        Me.lblAverage2.Size = New System.Drawing.Size(128, 23)
        Me.lblAverage2.TabIndex = 35
        '
        'lblAverage3
        '
        Me.lblAverage3.BackColor = System.Drawing.SystemColors.Control
        Me.lblAverage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAverage3.Location = New System.Drawing.Point(303, 289)
        Me.lblAverage3.Name = "lblAverage3"
        Me.lblAverage3.Size = New System.Drawing.Size(131, 23)
        Me.lblAverage3.TabIndex = 34
        '
        'lblTotalAverage
        '
        Me.lblTotalAverage.BackColor = System.Drawing.SystemColors.Control
        Me.lblTotalAverage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotalAverage.Location = New System.Drawing.Point(49, 331)
        Me.lblTotalAverage.Name = "lblTotalAverage"
        Me.lblTotalAverage.Size = New System.Drawing.Size(363, 23)
        Me.lblTotalAverage.TabIndex = 33
        '
        'lblUnits3
        '
        Me.lblUnits3.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblUnits3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUnits3.Location = New System.Drawing.Point(303, 114)
        Me.lblUnits3.Name = "lblUnits3"
        Me.lblUnits3.Size = New System.Drawing.Size(131, 156)
        Me.lblUnits3.TabIndex = 32
        '
        'lblUnits2
        '
        Me.lblUnits2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblUnits2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUnits2.Location = New System.Drawing.Point(162, 114)
        Me.lblUnits2.Name = "lblUnits2"
        Me.lblUnits2.Size = New System.Drawing.Size(128, 156)
        Me.lblUnits2.TabIndex = 31
        '
        'lblUnits1
        '
        Me.lblUnits1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblUnits1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblUnits1.Location = New System.Drawing.Point(8, 114)
        Me.lblUnits1.Name = "lblUnits1"
        Me.lblUnits1.Size = New System.Drawing.Size(134, 156)
        Me.lblUnits1.TabIndex = 30
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(303, 372)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(91, 28)
        Me.btnExit.TabIndex = 29
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(191, 372)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 28)
        Me.btnReset.TabIndex = 28
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(64, 372)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(79, 28)
        Me.btnEnter.TabIndex = 27
        Me.btnEnter.Text = "&Enter"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'lblEm3
        '
        Me.lblEm3.AutoSize = True
        Me.lblEm3.Location = New System.Drawing.Point(330, 81)
        Me.lblEm3.Name = "lblEm3"
        Me.lblEm3.Size = New System.Drawing.Size(82, 17)
        Me.lblEm3.TabIndex = 26
        Me.lblEm3.Text = "Employee 3"
        '
        'lblEm2
        '
        Me.lblEm2.AutoSize = True
        Me.lblEm2.Location = New System.Drawing.Point(188, 81)
        Me.lblEm2.Name = "lblEm2"
        Me.lblEm2.Size = New System.Drawing.Size(82, 17)
        Me.lblEm2.TabIndex = 25
        Me.lblEm2.Text = "Employee 2"
        '
        'lblEm1
        '
        Me.lblEm1.AutoSize = True
        Me.lblEm1.Location = New System.Drawing.Point(29, 81)
        Me.lblEm1.Name = "lblEm1"
        Me.lblEm1.Size = New System.Drawing.Size(82, 17)
        Me.lblEm1.TabIndex = 24
        Me.lblEm1.Text = "Employee 1"
        '
        'txtUnits
        '
        Me.txtUnits.Location = New System.Drawing.Point(64, 38)
        Me.txtUnits.Name = "txtUnits"
        Me.txtUnits.Size = New System.Drawing.Size(61, 22)
        Me.txtUnits.TabIndex = 23
        '
        'lblUnits
        '
        Me.lblUnits.AutoSize = True
        Me.lblUnits.Location = New System.Drawing.Point(14, 38)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(44, 17)
        Me.lblUnits.TabIndex = 22
        Me.lblUnits.Text = "Units:"
        '
        'lblDays
        '
        Me.lblDays.AutoSize = True
        Me.lblDays.Location = New System.Drawing.Point(14, 16)
        Me.lblDays.Name = "lblDays"
        Me.lblDays.Size = New System.Drawing.Size(45, 17)
        Me.lblDays.TabIndex = 21
        Me.lblDays.Text = "Day 1"
        '
        'frmAverageUnitsShippedByEmployee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(442, 416)
        Me.Controls.Add(Me.lblAverage1)
        Me.Controls.Add(Me.lblAverage2)
        Me.Controls.Add(Me.lblAverage3)
        Me.Controls.Add(Me.lblTotalAverage)
        Me.Controls.Add(Me.lblUnits3)
        Me.Controls.Add(Me.lblUnits2)
        Me.Controls.Add(Me.lblUnits1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblEm3)
        Me.Controls.Add(Me.lblEm2)
        Me.Controls.Add(Me.lblEm1)
        Me.Controls.Add(Me.txtUnits)
        Me.Controls.Add(Me.lblUnits)
        Me.Controls.Add(Me.lblDays)
        Me.Name = "frmAverageUnitsShippedByEmployee"
        Me.Text = "AverageUnitsShippedByEmployee"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblAverage1 As Label
    Friend WithEvents lblAverage2 As Label
    Friend WithEvents lblAverage3 As Label
    Friend WithEvents lblTotalAverage As Label
    Friend WithEvents lblUnits3 As Label
    Friend WithEvents lblUnits2 As Label
    Friend WithEvents lblUnits1 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnEnter As Button
    Friend WithEvents lblEm3 As Label
    Friend WithEvents lblEm2 As Label
    Friend WithEvents lblEm1 As Label
    Friend WithEvents txtUnits As TextBox
    Friend WithEvents lblUnits As Label
    Friend WithEvents lblDays As Label
End Class
