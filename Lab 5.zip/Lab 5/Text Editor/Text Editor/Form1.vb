﻿Option Strict On

Imports System.IO
Imports System.Text

''' <summary>
''' Author Name:    Cowshigan Varnakunasingam
''' Project Name:   Text Editor
''' Date:           05-April-2019
''' Description     Help users to create and edit any text files that is within their computer.
''' </summary>
''' 
Public Class frmTextEditor
    Private fStream As FileStream
    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MsgBox("NETD-2202" & vbNewLine & "Lab# 5" & vbNewLine & "C.Varnakunasingam")
    End Sub

    Private Sub CopyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyToolStripMenuItem.Click
        My.Computer.Clipboard.SetText(txtFileInput.SelectedText)
    End Sub

    Private Sub CutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CutToolStripMenuItem.Click
        My.Computer.Clipboard.SetText(txtFileInput.SelectedText)
        txtFileInput.SelectedText = ""
    End Sub

    Private Sub PasteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PasteToolStripMenuItem.Click
        txtFileInput.SelectedText = My.Computer.Clipboard.GetText
    End Sub

    Private Sub NewToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewToolStripMenuItem.Click
        txtFileInput.Clear()
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        OpenFileDialog1.ShowDialog()
    End Sub

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem.Click
        Dim fileWords As Byte() = New UTF8Encoding(True).GetBytes(txtFileInput.Text)
        Try
            fStream.Write(fileWords, 0, fileWords.Length)
            fStream.Close()
            MsgBox("Textfile Saved")
        Catch ex As Exception
            SaveFileDialog1.ShowDialog()
        End Try
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SaveAsToolStripMenuItem.Click
        SaveFileDialog1.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub OpenFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        Dim rStream As New StreamReader(OpenFileDialog1.FileName)
        OpenFileDialog1.CheckFileExists = True
        txtFileInput.Text = rStream.ReadToEnd()
        rStream.Close()
        fStream = File.OpenWrite(OpenFileDialog1.FileName)
    End Sub

    Private Sub SaveFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk
        Dim wStream As New StreamWriter(SaveFileDialog1.FileName)
        wStream.Write(txtFileInput.Text)
        wStream.Close()
    End Sub
End Class
