﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCarInvent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblResult = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.lblMakePrompt = New System.Windows.Forms.Label()
        Me.colPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Price = New System.Windows.Forms.Label()
        Me.colModel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colNew = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.lvwCars = New System.Windows.Forms.ListView()
        Me.colMake = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chkNew = New System.Windows.Forms.CheckBox()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.txtModel = New System.Windows.Forms.TextBox()
        Me.cmbYear = New System.Windows.Forms.ComboBox()
        Me.cmbMake = New System.Windows.Forms.ComboBox()
        Me.CarInventoryTips = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'lblResult
        '
        Me.lblResult.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblResult.Location = New System.Drawing.Point(9, 428)
        Me.lblResult.Name = "lblResult"
        Me.lblResult.Size = New System.Drawing.Size(454, 83)
        Me.lblResult.TabIndex = 24
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(370, 524)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(94, 31)
        Me.btnExit.TabIndex = 27
        Me.btnExit.Text = "E&xit"
        Me.CarInventoryTips.SetToolTip(Me.btnExit, "Exit the Program")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(270, 524)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(94, 31)
        Me.btnReset.TabIndex = 26
        Me.btnReset.Text = "&Reset"
        Me.CarInventoryTips.SetToolTip(Me.btnReset, "Restart the Program")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(170, 524)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(94, 31)
        Me.btnEnter.TabIndex = 25
        Me.btnEnter.Text = "&Enter"
        Me.CarInventoryTips.SetToolTip(Me.btnEnter, "Enter the Car Details")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'lblYear
        '
        Me.lblYear.Location = New System.Drawing.Point(8, 76)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(83, 23)
        Me.lblYear.TabIndex = 18
        Me.lblYear.Text = "&Year:"
        Me.lblYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblModel
        '
        Me.lblModel.Location = New System.Drawing.Point(8, 43)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(83, 23)
        Me.lblModel.TabIndex = 16
        Me.lblModel.Text = "&Model:"
        Me.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblMakePrompt
        '
        Me.lblMakePrompt.Location = New System.Drawing.Point(8, 10)
        Me.lblMakePrompt.Name = "lblMakePrompt"
        Me.lblMakePrompt.Size = New System.Drawing.Size(83, 23)
        Me.lblMakePrompt.TabIndex = 14
        Me.lblMakePrompt.Text = "Ma&ke:"
        Me.lblMakePrompt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'colPrice
        '
        Me.colPrice.Text = "Price"
        '
        'colYear
        '
        Me.colYear.Text = "Year"
        '
        'Price
        '
        Me.Price.Location = New System.Drawing.Point(8, 109)
        Me.Price.Name = "Price"
        Me.Price.Size = New System.Drawing.Size(83, 23)
        Me.Price.TabIndex = 20
        Me.Price.Text = "&Price:"
        Me.Price.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'colModel
        '
        Me.colModel.Text = "Model"
        '
        'colID
        '
        Me.colID.Text = "ID"
        '
        'colNew
        '
        Me.colNew.Text = "New"
        '
        'lvwCars
        '
        Me.lvwCars.BackColor = System.Drawing.SystemColors.Window
        Me.lvwCars.CheckBoxes = True
        Me.lvwCars.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colNew, Me.colID, Me.colMake, Me.colModel, Me.colYear, Me.colPrice})
        Me.lvwCars.FullRowSelect = True
        Me.lvwCars.Location = New System.Drawing.Point(8, 172)
        Me.lvwCars.MultiSelect = False
        Me.lvwCars.Name = "lvwCars"
        Me.lvwCars.Size = New System.Drawing.Size(456, 253)
        Me.lvwCars.TabIndex = 23
        Me.lvwCars.TileSize = New System.Drawing.Size(10, 10)
        Me.CarInventoryTips.SetToolTip(Me.lvwCars, "Select a car to modify.")
        Me.lvwCars.UseCompatibleStateImageBehavior = False
        Me.lvwCars.View = System.Windows.Forms.View.Details
        '
        'colMake
        '
        Me.colMake.Text = "Make"
        '
        'chkNew
        '
        Me.chkNew.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkNew.Location = New System.Drawing.Point(31, 142)
        Me.chkNew.Name = "chkNew"
        Me.chkNew.Size = New System.Drawing.Size(81, 24)
        Me.chkNew.TabIndex = 22
        Me.chkNew.Text = "&New:"
        Me.chkNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CarInventoryTips.SetToolTip(Me.chkNew, "Check if the Car is New.")
        Me.chkNew.UseVisualStyleBackColor = True
        '
        'txtPrice
        '
        Me.txtPrice.Location = New System.Drawing.Point(95, 109)
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(119, 22)
        Me.txtPrice.TabIndex = 21
        Me.CarInventoryTips.SetToolTip(Me.txtPrice, "Enter Model")
        '
        'txtModel
        '
        Me.txtModel.Location = New System.Drawing.Point(95, 43)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(119, 22)
        Me.txtModel.TabIndex = 17
        Me.CarInventoryTips.SetToolTip(Me.txtModel, "Enter Model")
        '
        'cmbYear
        '
        Me.cmbYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbYear.FormattingEnabled = True
        Me.cmbYear.Items.AddRange(New Object() {"2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995"})
        Me.cmbYear.Location = New System.Drawing.Point(95, 76)
        Me.cmbYear.Name = "cmbYear"
        Me.cmbYear.Size = New System.Drawing.Size(121, 24)
        Me.cmbYear.TabIndex = 19
        Me.CarInventoryTips.SetToolTip(Me.cmbYear, "Select the Car Year.")
        '
        'cmbMake
        '
        Me.cmbMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbMake.FormattingEnabled = True
        Me.cmbMake.Items.AddRange(New Object() {"Honda", "Acura", "Toyota", "Subaru", "Dodge", "Chevrolet", "Chrysler", "Ford", "Nissan", "Lexus", "Infiniti", "BMW", "Audi", "Mercedes", "Volkswagen", "Volvo"})
        Me.cmbMake.Location = New System.Drawing.Point(95, 10)
        Me.cmbMake.Name = "cmbMake"
        Me.cmbMake.Size = New System.Drawing.Size(121, 24)
        Me.cmbMake.TabIndex = 15
        Me.CarInventoryTips.SetToolTip(Me.cmbMake, "Select the Car Brand.")
        '
        'frmCarInvent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(472, 565)
        Me.Controls.Add(Me.lblResult)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.lblModel)
        Me.Controls.Add(Me.lblMakePrompt)
        Me.Controls.Add(Me.Price)
        Me.Controls.Add(Me.lvwCars)
        Me.Controls.Add(Me.chkNew)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.txtModel)
        Me.Controls.Add(Me.cmbYear)
        Me.Controls.Add(Me.cmbMake)
        Me.Name = "frmCarInvent"
        Me.Text = "Car Inventory"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblResult As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents CarInventoryTips As ToolTip
    Friend WithEvents btnReset As Button
    Friend WithEvents btnEnter As Button
    Friend WithEvents lblYear As Label
    Friend WithEvents lblModel As Label
    Friend WithEvents lblMakePrompt As Label
    Friend WithEvents colPrice As ColumnHeader
    Friend WithEvents colYear As ColumnHeader
    Friend WithEvents Price As Label
    Friend WithEvents colModel As ColumnHeader
    Friend WithEvents colID As ColumnHeader
    Friend WithEvents colNew As ColumnHeader
    Friend WithEvents lvwCars As ListView
    Friend WithEvents colMake As ColumnHeader
    Friend WithEvents chkNew As CheckBox
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents txtModel As TextBox
    Friend WithEvents cmbYear As ComboBox
    Friend WithEvents cmbMake As ComboBox
End Class
